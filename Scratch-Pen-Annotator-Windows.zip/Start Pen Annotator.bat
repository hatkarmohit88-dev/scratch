@echo off
setlocal
wscript.exe "%~dp0Start Pen Annotator.vbs"
