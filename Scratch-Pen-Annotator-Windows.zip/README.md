# On-screen Pen Annotator (Windows)

A small floating toolbar for drawing on top of your Windows desktop. It uses
Windows PowerShell and WPF, which are included with Windows; no extra software
or coding is needed. A separate toolbar appears near the top of every connected
display, and each toolbar controls the same desktop drawing layer.

## Start the app

Double-click **Start Pen Annotator.vbs**. This starts the desktop toolbar
without leaving a PowerShell console open. You can also double-click
**Start Pen Annotator.bat**.

## Use it

- The cursor button lets mouse clicks pass through so you can use other apps.
- The pen button lets you draw on top of any app and opens a size bar you can
  drag anywhere along to set the width.
- Pen strokes use rounded, smoothed curves.
- The red circle is the default pen color. Click it to open the color palette;
  opening the palette does not change the selected color. Choose a standard
  color or the multicolor button for a custom color.
- The eraser button opens a matching size bar. Its circular on-screen outline
  shows the erasing area; brush over a stroke to erase only the covered
  portion.
- Undo and redo reverse drawing, erasing, and clearing.
- The trash button removes every drawing.
- The three dots are the only part you can drag to move a toolbar.
- The red X closes the tool.

The square-cornered, dark translucent gray toolbar stays above other windows.
Choose the cursor button to interact with the desktop, or choose the pen or
eraser to annotate. The app does not save drawings, and closing it clears them.
It is intended for Windows only.
