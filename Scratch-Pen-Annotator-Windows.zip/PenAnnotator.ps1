$ErrorActionPreference = 'Stop'

try {
    Add-Type -AssemblyName PresentationFramework
    Add-Type -AssemblyName PresentationCore
    Add-Type -AssemblyName WindowsBase
    Add-Type -AssemblyName System.Xaml
    Add-Type -AssemblyName System.Windows.Forms

    $nativeCode = @'
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Windows;

namespace PenAnnotator {
    public static class StrokeGeometry {
        private static void AddPoint(List<Point> points, Point point) {
            if (points.Count > 0) {
                Point last = points[points.Count - 1];
                double dx = point.X - last.X;
                double dy = point.Y - last.Y;
                if (dx * dx + dy * dy < 0.01)
                    return;
            }
            points.Add(point);
        }

        private static void CompleteFragment(List<Point[]> fragments, List<Point> current) {
            if (current.Count > 0) {
                fragments.Add(current.ToArray());
                current.Clear();
            }
        }

        private static bool TryInsideInterval(double a, double b, double c,
                                              double minimum, double maximum,
                                              out double insideStart, out double insideEnd) {
            const double epsilon = 1e-10;
            insideStart = minimum;
            insideEnd = maximum;
            if (Math.Abs(a) <= epsilon) {
                if (Math.Abs(b) <= epsilon)
                    return c <= 0;
                double root = -c / b;
                if (b > 0)
                    insideEnd = Math.Min(maximum, root);
                else
                    insideStart = Math.Max(minimum, root);
            } else {
                double discriminant = b * b - 4 * a * c;
                if (discriminant < 0) {
                    double middle = (minimum + maximum) / 2;
                    return a * middle * middle + b * middle + c <= 0;
                }
                double root = Math.Sqrt(discriminant);
                double first = (-b - root) / (2 * a);
                double second = (-b + root) / (2 * a);
                insideStart = Math.Max(minimum, first);
                insideEnd = Math.Min(maximum, second);
            }
            return insideEnd - insideStart > 1e-6;
        }

        private static bool TryCapsuleInterval(Point strokeStart, Point strokeEnd,
                                               Point eraserStart, Point eraserEnd,
                                               double radius, out double insideStart,
                                               out double insideEnd) {
            double strokeDx = strokeEnd.X - strokeStart.X;
            double strokeDy = strokeEnd.Y - strokeStart.Y;
            double pathDx = eraserEnd.X - eraserStart.X;
            double pathDy = eraserEnd.Y - eraserStart.Y;
            double pathLengthSquared = pathDx * pathDx + pathDy * pathDy;
            if (pathLengthSquared <= 1e-7) {
                double fromX = strokeStart.X - eraserStart.X;
                double fromY = strokeStart.Y - eraserStart.Y;
                return TryInsideInterval(
                    strokeDx * strokeDx + strokeDy * strokeDy,
                    2 * (fromX * strokeDx + fromY * strokeDy),
                    fromX * fromX + fromY * fromY - radius * radius,
                    0, 1, out insideStart, out insideEnd);
            }

            double relativeX = strokeStart.X - eraserStart.X;
            double relativeY = strokeStart.Y - eraserStart.Y;
            double projectionStart = (relativeX * pathDx + relativeY * pathDy) /
                pathLengthSquared;
            double projectionDelta = (strokeDx * pathDx + strokeDy * pathDy) /
                pathLengthSquared;
            double[] breaks = new double[4];
            int breakCount = 0;
            breaks[breakCount++] = 0;
            breaks[breakCount++] = 1;
            if (Math.Abs(projectionDelta) > 1e-7) {
                double crossing = -projectionStart / projectionDelta;
                if (crossing > 0 && crossing < 1)
                    breaks[breakCount++] = crossing;
                crossing = (1 - projectionStart) / projectionDelta;
                if (crossing > 0 && crossing < 1)
                    breaks[breakCount++] = crossing;
            }
            Array.Sort(breaks, 0, breakCount);

            bool found = false;
            insideStart = 1;
            insideEnd = 0;
            for (int index = 1; index < breakCount; index++) {
                double minimum = breaks[index - 1];
                double maximum = breaks[index];
                if (maximum - minimum <= 1e-7)
                    continue;

                double middle = (minimum + maximum) / 2;
                double projection = projectionStart + projectionDelta * middle;
                double a, b, c;
                if (projection <= 0 || projection >= 1) {
                    Point cap = projection <= 0 ? eraserStart : eraserEnd;
                    double fromX = strokeStart.X - cap.X;
                    double fromY = strokeStart.Y - cap.Y;
                    a = strokeDx * strokeDx + strokeDy * strokeDy;
                    b = 2 * (fromX * strokeDx + fromY * strokeDy);
                    c = fromX * fromX + fromY * fromY - radius * radius;
                } else {
                    double crossStart = pathDx * relativeY - pathDy * relativeX;
                    double crossDelta = pathDx * strokeDy - pathDy * strokeDx;
                    a = crossDelta * crossDelta / pathLengthSquared;
                    b = 2 * crossStart * crossDelta / pathLengthSquared;
                    c = crossStart * crossStart / pathLengthSquared - radius * radius;
                }

                double intervalStart, intervalEnd;
                if (TryInsideInterval(a, b, c, minimum, maximum,
                                      out intervalStart, out intervalEnd)) {
                    found = true;
                    insideStart = Math.Min(insideStart, intervalStart);
                    insideEnd = Math.Max(insideEnd, intervalEnd);
                }
            }
            return found && insideEnd - insideStart > 1e-6;
        }

        private static double DistanceToSegment(Point point, Point start, Point end) {
            double dx = end.X - start.X;
            double dy = end.Y - start.Y;
            double lengthSquared = dx * dx + dy * dy;
            double ratio = lengthSquared <= 0 ? 0 :
                ((point.X - start.X) * dx + (point.Y - start.Y) * dy) / lengthSquared;
            ratio = Math.Max(0, Math.Min(1, ratio));
            double diffX = point.X - (start.X + ratio * dx);
            double diffY = point.Y - (start.Y + ratio * dy);
            return Math.Sqrt(diffX * diffX + diffY * diffY);
        }

        public static List<Point[]> EraseStroke(IList<Point> points, Point eraserStart,
                                                Point eraserEnd, double radius,
                                                out bool changed) {
            List<Point[]> fragments = new List<Point[]>();
            changed = false;
            if (points.Count == 0)
                return fragments;
            if (points.Count == 1) {
                if (DistanceToSegment(points[0], eraserStart, eraserEnd) <= radius) {
                    changed = true;
                } else {
                    fragments.Add(new Point[] { points[0] });
                }
                return fragments;
            }

            double minX = Math.Min(eraserStart.X, eraserEnd.X) - radius;
            double maxX = Math.Max(eraserStart.X, eraserEnd.X) + radius;
            double minY = Math.Min(eraserStart.Y, eraserEnd.Y) - radius;
            double maxY = Math.Max(eraserStart.Y, eraserEnd.Y) + radius;
            List<Point> current = new List<Point>();
            for (int index = 1; index < points.Count; index++) {
                Point start = points[index - 1];
                Point end = points[index];
                if (Math.Max(start.X, end.X) < minX || Math.Min(start.X, end.X) > maxX ||
                    Math.Max(start.Y, end.Y) < minY || Math.Min(start.Y, end.Y) > maxY) {
                    AddPoint(current, start);
                    AddPoint(current, end);
                    continue;
                }

                double cutStart, cutEnd;
                if (!TryCapsuleInterval(start, end, eraserStart, eraserEnd, radius,
                                        out cutStart, out cutEnd)) {
                    AddPoint(current, start);
                    AddPoint(current, end);
                    continue;
                }

                changed = true;
                double dx = end.X - start.X;
                double dy = end.Y - start.Y;
                if (cutStart > 1e-6) {
                    AddPoint(current, start);
                    AddPoint(current, new Point(start.X + dx * cutStart,
                                                start.Y + dy * cutStart));
                }
                CompleteFragment(fragments, current);
                if (cutEnd < 1 - 1e-6) {
                    AddPoint(current, new Point(start.X + dx * cutEnd,
                                                start.Y + dy * cutEnd));
                    AddPoint(current, end);
                }
            }
            CompleteFragment(fragments, current);
            return fragments;
        }
    }

    public static class WindowStyles {
        private const int GWL_EXSTYLE = -20;
        private const long WS_EX_TRANSPARENT = 0x00000020L;
        private const long WS_EX_TOOLWINDOW = 0x00000080L;
        private const long WS_EX_NOACTIVATE = 0x08000000L;

        [DllImport("user32.dll", EntryPoint = "GetWindowLong", SetLastError = true)]
        private static extern int GetWindowLong32(IntPtr handle, int index);
        [DllImport("user32.dll", EntryPoint = "SetWindowLong", SetLastError = true)]
        private static extern int SetWindowLong32(IntPtr handle, int index, int value);
        [DllImport("user32.dll", EntryPoint = "GetWindowLongPtr", SetLastError = true)]
        private static extern IntPtr GetWindowLongPtr64(IntPtr handle, int index);
        [DllImport("user32.dll", EntryPoint = "SetWindowLongPtr", SetLastError = true)]
        private static extern IntPtr SetWindowLongPtr64(IntPtr handle, int index, IntPtr value);
        [DllImport("user32.dll", SetLastError = true)]
        private static extern bool SetWindowPos(IntPtr handle, IntPtr insertAfter, int x, int y,
            int width, int height, uint flags);

        public static void BringToFront(IntPtr handle) {
            SetWindowPos(handle, new IntPtr(-1), 0, 0, 0, 0, 0x0001 | 0x0002 | 0x0010);
        }

        public static void SetOverlayMode(IntPtr handle, bool passThrough) {
            long style = IntPtr.Size == 8
                ? GetWindowLongPtr64(handle, GWL_EXSTYLE).ToInt64()
                : GetWindowLong32(handle, GWL_EXSTYLE);
            style |= WS_EX_TOOLWINDOW | WS_EX_NOACTIVATE;
            if (passThrough)
                style |= WS_EX_TRANSPARENT;
            else
                style &= ~WS_EX_TRANSPARENT;

            if (IntPtr.Size == 8)
                SetWindowLongPtr64(handle, GWL_EXSTYLE, new IntPtr(style));
            else
                SetWindowLong32(handle, GWL_EXSTYLE, unchecked((int)style));

            SetWindowPos(handle, IntPtr.Zero, 0, 0, 0, 0, 0x0001 | 0x0002 | 0x0004 | 0x0010);
        }
    }
}
'@
    $windowsBaseAssembly = [System.Reflection.Assembly]::GetAssembly(
        [System.Windows.Point]).Location
    Add-Type -TypeDefinition $nativeCode -ReferencedAssemblies @($windowsBaseAssembly)

    $overlayXaml = @'
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        WindowStyle="None" ResizeMode="NoResize" AllowsTransparency="True"
        Background="#01000000" ShowInTaskbar="False" Topmost="True"
        ShowActivated="False" Focusable="False">
    <!-- A nonzero alpha lets this layered overlay receive input in Pen and Erase modes. -->
    <Canvas x:Name="DrawingCanvas" Background="#01000000">
        <Ellipse x:Name="EraserCursor" Visibility="Collapsed" IsHitTestVisible="False"
                 Stroke="#E8E8E8" StrokeThickness="1.5" Fill="#22000000" />
    </Canvas>
</Window>
'@
    $toolbarXaml = @'
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="On-screen Pen" WindowStyle="None" ResizeMode="NoResize"
        Width="418" Height="60" ShowInTaskbar="False" Topmost="True"
        AllowsTransparency="True" Background="Transparent" FontFamily="Segoe UI">
    <Window.Resources>
        <Style x:Key="ModernSliderDecreaseButton" TargetType="{x:Type RepeatButton}">
            <Setter Property="Focusable" Value="False" />
            <Setter Property="IsHitTestVisible" Value="False" />
            <Setter Property="Template">
                <Setter.Value>
                    <ControlTemplate TargetType="{x:Type RepeatButton}">
                        <Border Height="6" Background="#9182F5" CornerRadius="3" />
                    </ControlTemplate>
                </Setter.Value>
            </Setter>
        </Style>
        <Style x:Key="ModernSliderIncreaseButton" TargetType="{x:Type RepeatButton}">
            <Setter Property="Focusable" Value="False" />
            <Setter Property="IsHitTestVisible" Value="False" />
            <Setter Property="Template">
                <Setter.Value>
                    <ControlTemplate TargetType="{x:Type RepeatButton}">
                        <Border Height="6" Background="Transparent" CornerRadius="3" />
                    </ControlTemplate>
                </Setter.Value>
            </Setter>
        </Style>
        <Style x:Key="ModernSliderThumb" TargetType="{x:Type Thumb}">
            <Setter Property="Width" Value="16" />
            <Setter Property="Height" Value="16" />
            <Setter Property="Focusable" Value="False" />
            <Setter Property="Template">
                <Setter.Value>
                    <ControlTemplate TargetType="{x:Type Thumb}">
                        <Ellipse Fill="#F4F4F5" Stroke="#9182F5" StrokeThickness="2.5" />
                    </ControlTemplate>
                </Setter.Value>
            </Setter>
        </Style>
        <Style x:Key="ModernSizeSlider" TargetType="{x:Type Slider}">
            <Setter Property="Height" Value="30" />
            <Setter Property="IsMoveToPointEnabled" Value="False" />
            <Setter Property="Template">
                <Setter.Value>
                    <ControlTemplate TargetType="{x:Type Slider}">
                        <Grid Background="Transparent">
                            <Border Height="6" Margin="8,0" Background="#45454B"
                                    CornerRadius="3" VerticalAlignment="Center" />
                            <Track x:Name="PART_Track" Margin="8,0"
                                   VerticalAlignment="Center"
                                   IsDirectionReversed="{TemplateBinding IsDirectionReversed}">
                                <Track.DecreaseRepeatButton>
                                    <RepeatButton Command="Slider.DecreaseLarge"
                                                  Style="{StaticResource ModernSliderDecreaseButton}" />
                                </Track.DecreaseRepeatButton>
                                <Track.Thumb>
                                    <Thumb Style="{StaticResource ModernSliderThumb}" />
                                </Track.Thumb>
                                <Track.IncreaseRepeatButton>
                                    <RepeatButton Command="Slider.IncreaseLarge"
                                                  Style="{StaticResource ModernSliderIncreaseButton}" />
                                </Track.IncreaseRepeatButton>
                            </Track>
                        </Grid>
                    </ControlTemplate>
                </Setter.Value>
            </Setter>
        </Style>
        <Style x:Key="ToolbarButton" TargetType="{x:Type Button}">
            <Setter Property="Background" Value="Transparent" />
            <Setter Property="Foreground" Value="#E6E6E8" />
            <Setter Property="BorderBrush" Value="Transparent" />
            <Setter Property="BorderThickness" Value="0" />
            <Setter Property="Width" Value="38" />
            <Setter Property="Height" Value="42" />
            <Setter Property="Margin" Value="3,0" />
            <Setter Property="Cursor" Value="Hand" />
            <Setter Property="FocusVisualStyle" Value="{x:Null}" />
            <Setter Property="Template">
                <Setter.Value>
                    <ControlTemplate TargetType="{x:Type Button}">
                        <Border x:Name="ButtonBorder" Background="{TemplateBinding Background}"
                                BorderBrush="{TemplateBinding BorderBrush}"
                                BorderThickness="{TemplateBinding BorderThickness}"
                                CornerRadius="0">
                            <ContentPresenter HorizontalAlignment="Center"
                                              VerticalAlignment="Center" />
                        </Border>
                        <ControlTemplate.Triggers>
                            <Trigger Property="IsMouseOver" Value="True">
                                <Setter TargetName="ButtonBorder" Property="Background" Value="#665D5D63" />
                            </Trigger>
                            <Trigger Property="IsEnabled" Value="False">
                                <Setter Property="Opacity" Value="0.4" />
                            </Trigger>
                        </ControlTemplate.Triggers>
                    </ControlTemplate>
                </Setter.Value>
            </Setter>
        </Style>
    </Window.Resources>
    <Grid>
        <Border x:Name="ToolbarSurface" Background="#E61B1B1F" BorderBrush="#8047474C"
                BorderThickness="1" Padding="7,5">
            <Grid>
            <Grid.ColumnDefinitions>
                <ColumnDefinition Width="*" /><ColumnDefinition Width="*" />
                <ColumnDefinition Width="*" /><ColumnDefinition Width="*" />
                <ColumnDefinition Width="*" /><ColumnDefinition Width="*" />
                <ColumnDefinition Width="*" /><ColumnDefinition Width="*" />
                <ColumnDefinition Width="*" />
            </Grid.ColumnDefinitions>
            <Border x:Name="DragGrip" Grid.Column="0" Width="38" Height="42" Margin="3,0"
                    Background="Transparent" Cursor="SizeAll" ToolTip="Drag to move">
                <StackPanel HorizontalAlignment="Center" VerticalAlignment="Center">
                    <Ellipse Width="3" Height="3" Fill="#D8D8DB" Margin="0,1" />
                    <Ellipse Width="3" Height="3" Fill="#D8D8DB" Margin="0,1" />
                    <Ellipse Width="3" Height="3" Fill="#D8D8DB" Margin="0,1" />
                </StackPanel>
            </Border>
            <Button x:Name="UndoButton" Grid.Column="1" Style="{StaticResource ToolbarButton}"
                    ToolTip="Undo" IsEnabled="False">
                <TextBlock Text="&#xE7A7;" FontFamily="Segoe MDL2 Assets" FontSize="16" />
            </Button>
            <Button x:Name="RedoButton" Grid.Column="2" Style="{StaticResource ToolbarButton}"
                    ToolTip="Redo" IsEnabled="False">
                <TextBlock Text="&#xE7A6;" FontFamily="Segoe MDL2 Assets" FontSize="16" />
            </Button>
            <Button x:Name="SelectButton" Grid.Column="3" Style="{StaticResource ToolbarButton}"
                    Background="#9958585E" ToolTip="Cursor: use the screen normally">
                <Path Data="M 2,1 L 2,23 L 8,17 L 12,27 L 16,25 L 12,15 L 21,15 Z"
                      Fill="#F5F5F5" Stroke="#202023" StrokeThickness="1" />
            </Button>
            <Button x:Name="PenButton" Grid.Column="4" Style="{StaticResource ToolbarButton}"
                    ToolTip="Pen: draw on the screen">
                <Path Data="M 3,21 L 7,20 L 20,7 Q 22,5 20,3 Q 18,1 16,3 L 4,16 Z M 3,21 L 4,16 M 7,20 L 4,16 M 14,5 L 18,9"
                      Stroke="#F3F3F4" StrokeThickness="1.8"
                      StrokeLineJoin="Round" StrokeStartLineCap="Round"
                      StrokeEndLineCap="Round" />
            </Button>
            <Button x:Name="ColorButton" Grid.Column="5" Style="{StaticResource ToolbarButton}"
                    ToolTip="Choose pen color">
                <Ellipse x:Name="ColorSwatch" Width="27" Height="27" Fill="#EF4444"
                         Stroke="#F5F5F5" StrokeThickness="2" />
            </Button>
            <Button x:Name="EraserButton" Grid.Column="6" Style="{StaticResource ToolbarButton}"
                    ToolTip="Erase strokes">
                <TextBlock Text="&#xE75C;" FontFamily="Segoe MDL2 Assets" FontSize="17" />
            </Button>
            <Button x:Name="ClearButton" Grid.Column="7" Style="{StaticResource ToolbarButton}"
                    ToolTip="Clear all drawings">
                <TextBlock Text="&#xE74D;" FontFamily="Segoe MDL2 Assets" FontSize="17" />
            </Button>
            <Button x:Name="CloseButton" Grid.Column="8" Style="{StaticResource ToolbarButton}"
                    BorderBrush="#4A4A4E" BorderThickness="1,0,0,0" ToolTip="Close annotator">
                <TextBlock Text="&#xE711;" Foreground="#F04444"
                           FontFamily="Segoe MDL2 Assets" FontSize="16" />
            </Button>
            </Grid>
        </Border>
        <Popup x:Name="PenSizePopup" Placement="Bottom" StaysOpen="True"
               AllowsTransparency="True">
            <Border Background="#F02B2B2F" BorderBrush="#806B6B70"
                    BorderThickness="1" Padding="12">
                <StackPanel Width="200">
                    <DockPanel Margin="0,0,0,8">
                        <TextBlock Text="Pen size" Foreground="#F3F3F4"
                                   FontSize="13" />
                        <TextBlock x:Name="PenSizeValue" Text="5 px" Foreground="#BFC0C4"
                                   FontSize="12" HorizontalAlignment="Right" DockPanel.Dock="Right" />
                    </DockPanel>
                    <Slider x:Name="PenSizeSlider" Style="{StaticResource ModernSizeSlider}"
                            Minimum="1" Maximum="20" Value="5" TickFrequency="1"
                            SmallChange="0.5" LargeChange="1" Margin="0,0,0,8" />
                    <Rectangle x:Name="PenSizePreview" Height="5" Fill="#EF4444"
                               HorizontalAlignment="Stretch" />
                </StackPanel>
            </Border>
        </Popup>
        <Popup x:Name="ColorPalettePopup" Placement="Bottom" StaysOpen="True"
               AllowsTransparency="True">
            <Border Background="#F02B2B2F" BorderBrush="#806B6B70"
                    BorderThickness="1" Padding="12">
                <StackPanel Width="200">
                    <TextBlock Text="Pen color" Foreground="#F3F3F4"
                               FontSize="13" Margin="0,0,0,6" />
                    <WrapPanel x:Name="PenColorPalette" Width="200">
                        <Button x:Name="RedPaletteButton" Tag="#EF4444" ToolTip="Red" Width="24" Height="24"
                                Padding="0" Margin="1" Background="Transparent" BorderThickness="0">
                            <Ellipse Width="16" Height="16" Fill="#EF4444"
                                     Stroke="#BFC0C4" StrokeThickness="1" />
                        </Button>
                        <Button x:Name="OrangePaletteButton" Tag="#F97316" ToolTip="Orange" Width="24" Height="24"
                                Padding="0" Margin="1" Background="Transparent" BorderThickness="0">
                            <Ellipse Width="16" Height="16" Fill="#F97316"
                                     Stroke="#BFC0C4" StrokeThickness="1" />
                        </Button>
                        <Button x:Name="YellowPaletteButton" Tag="#FACC15" ToolTip="Yellow" Width="24" Height="24"
                                Padding="0" Margin="1" Background="Transparent" BorderThickness="0">
                            <Ellipse Width="16" Height="16" Fill="#FACC15"
                                     Stroke="#BFC0C4" StrokeThickness="1" />
                        </Button>
                        <Button x:Name="GreenPaletteButton" Tag="#22C55E" ToolTip="Green" Width="24" Height="24"
                                Padding="0" Margin="1" Background="Transparent" BorderThickness="0">
                            <Ellipse Width="16" Height="16" Fill="#22C55E"
                                     Stroke="#BFC0C4" StrokeThickness="1" />
                        </Button>
                        <Button x:Name="CyanPaletteButton" Tag="#06B6D4" ToolTip="Cyan" Width="24" Height="24"
                                Padding="0" Margin="1" Background="Transparent" BorderThickness="0">
                            <Ellipse Width="16" Height="16" Fill="#06B6D4"
                                     Stroke="#BFC0C4" StrokeThickness="1" />
                        </Button>
                        <Button x:Name="BluePaletteButton" Tag="#3B82F6" ToolTip="Blue" Width="24" Height="24"
                                Padding="0" Margin="1" Background="Transparent" BorderThickness="0">
                            <Ellipse Width="16" Height="16" Fill="#3B82F6"
                                     Stroke="#BFC0C4" StrokeThickness="1" />
                        </Button>
                        <Button x:Name="PurplePaletteButton" Tag="#A855F7" ToolTip="Purple" Width="24" Height="24"
                                Padding="0" Margin="1" Background="Transparent" BorderThickness="0">
                            <Ellipse Width="16" Height="16" Fill="#A855F7"
                                     Stroke="#BFC0C4" StrokeThickness="1" />
                        </Button>
                        <Button x:Name="WhitePaletteButton" Tag="#FFFFFF" ToolTip="White" Width="24" Height="24"
                                Padding="0" Margin="1" Background="Transparent" BorderThickness="0">
                            <Ellipse Width="16" Height="16" Fill="#FFFFFF"
                                     Stroke="#BFC0C4" StrokeThickness="1" />
                        </Button>
                        <Button x:Name="BlackPaletteButton" Tag="#111827" ToolTip="Black" Width="24" Height="24"
                                Padding="0" Margin="1" Background="Transparent" BorderThickness="0">
                            <Ellipse Width="16" Height="16" Fill="#111827"
                                     Stroke="#BFC0C4" StrokeThickness="1" />
                        </Button>
                        <Button x:Name="CustomPenColorButton" ToolTip="Choose a custom color"
                                Width="24" Height="24" Padding="0" Margin="1"
                                Background="Transparent" BorderThickness="0">
                            <Ellipse Width="17" Height="17" Stroke="#F3F3F4" StrokeThickness="1">
                                <Ellipse.Fill>
                                    <LinearGradientBrush StartPoint="0,0" EndPoint="1,1">
                                        <GradientStop Color="#EF4444" Offset="0" />
                                        <GradientStop Color="#FACC15" Offset="0.2" />
                                        <GradientStop Color="#22C55E" Offset="0.4" />
                                        <GradientStop Color="#06B6D4" Offset="0.6" />
                                        <GradientStop Color="#3B82F6" Offset="0.8" />
                                        <GradientStop Color="#A855F7" Offset="1" />
                                    </LinearGradientBrush>
                                </Ellipse.Fill>
                            </Ellipse>
                        </Button>
                    </WrapPanel>
                </StackPanel>
            </Border>
        </Popup>
        <Popup x:Name="EraserSizePopup" Placement="Bottom" StaysOpen="True"
               AllowsTransparency="True">
            <Border Background="#F02B2B2F" BorderBrush="#806B6B70"
                    BorderThickness="1" Padding="12">
                <StackPanel Width="200">
                    <DockPanel Margin="0,0,0,6">
                        <TextBlock Text="Eraser size" Foreground="#F3F3F4"
                                   FontSize="13" />
                        <TextBlock x:Name="EraserSizeValue" Text="24 px" Foreground="#BFC0C4"
                                   FontSize="12" HorizontalAlignment="Right" DockPanel.Dock="Right" />
                    </DockPanel>
                    <Slider x:Name="EraserSizeSlider" Style="{StaticResource ModernSizeSlider}"
                            Minimum="8" Maximum="64" Value="24" TickFrequency="1"
                            SmallChange="1" LargeChange="4" Margin="0,0,0,8" />
                    <Grid Width="72" Height="72">
                        <Ellipse x:Name="EraserSizePreview" Width="24" Height="24"
                                 Stroke="#F3F3F4" StrokeThickness="1.5"
                                 HorizontalAlignment="Center" VerticalAlignment="Center" />
                    </Grid>
                </StackPanel>
            </Border>
        </Popup>
    </Grid>
</Window>
'@

    $script:overlay = [Windows.Markup.XamlReader]::Parse($overlayXaml)
    $script:toolbars = New-Object 'System.Collections.Generic.List[object]'
    $script:screens = [System.Windows.Forms.Screen]::AllScreens
    foreach ($screen in $script:screens) {
        [void]$script:toolbars.Add([Windows.Markup.XamlReader]::Parse($toolbarXaml))
    }
    $script:canvas = $script:overlay.FindName('DrawingCanvas')
    $script:eraserCursor = $script:overlay.FindName('EraserCursor')
    $script:strokes = New-Object 'System.Collections.Generic.List[object]'
    $script:undoStack = New-Object System.Collections.ArrayList
    $script:redoStack = New-Object System.Collections.ArrayList
    $script:mode = 'Select'
    $script:overlayHandle = [IntPtr]::Zero
    $script:isDrawing = $false
    $script:isErasing = $false
    $script:eraseChanged = $false
    $script:lastErasePoint = $null
    $script:activeSizeSlider = $null
    $script:activeStroke = $null
    $script:penColor = '#EF4444'
    $script:penWidth = 5
    $script:eraserSize = 24
    $script:eraserCursorTimer = New-Object System.Windows.Threading.DispatcherTimer
    $script:eraserCursorTimer.Interval = [TimeSpan]::FromMilliseconds(8)
    $script:eraserCursorTimer.Add_Tick({
        if ($script:mode -eq 'Erase') {
            Update-EraserCursor ([System.Windows.Input.Mouse]::GetPosition($script:canvas))
        }
    })

    function Get-StrokeSnapshot {
        return ,$script:strokes.ToArray()
    }

    function Update-HistoryButtons {
        foreach ($toolbar in $script:toolbars) {
            ([System.Windows.Controls.Button]$toolbar.FindName('UndoButton')).IsEnabled =
                $script:undoStack.Count -gt 0
            ([System.Windows.Controls.Button]$toolbar.FindName('RedoButton')).IsEnabled =
                $script:redoStack.Count -gt 0
        }
    }

    function Update-SizeSliderFromPointer($slider, [System.Windows.Point]$point) {
        $trackWidth = $slider.ActualWidth - 16
        if ($trackWidth -le 0) {
            return
        }
        $ratio = ($point.X - 8) / $trackWidth
        $ratio = [Math]::Max(0.0, [Math]::Min(1.0, [double]$ratio))
        $slider.Value = $slider.Minimum + $ratio * ($slider.Maximum - $slider.Minimum)
    }

    function Save-UndoSnapshot([object[]]$snapshot) {
        if ($script:undoStack.Count -ge 100) {
            $script:undoStack.RemoveAt(0)
        }
        [void]$script:undoStack.Add($snapshot)
        $script:redoStack.Clear()
        Update-HistoryButtons
    }

    function Restore-Strokes([object[]]$snapshot) {
        $script:strokes.Clear()
        $script:canvas.Children.Clear()
        foreach ($stroke in $snapshot) {
            $script:strokes.Add($stroke)
            [void]$script:canvas.Children.Add($stroke.Shape)
        }
        [void]$script:canvas.Children.Add($script:eraserCursor)
        [System.Windows.Controls.Panel]::SetZIndex($script:eraserCursor, 1000)
    }

    function Update-EraserCursor($point) {
        $diameter = $script:eraserSize
        $script:eraserCursor.Width = $diameter
        $script:eraserCursor.Height = $diameter
        [System.Windows.Controls.Canvas]::SetLeft($script:eraserCursor, $point.X - $diameter / 2)
        [System.Windows.Controls.Canvas]::SetTop($script:eraserCursor, $point.Y - $diameter / 2)
        [System.Windows.Controls.Panel]::SetZIndex($script:eraserCursor, 1000)
    }

    function Set-PenWidth([double]$width) {
        $script:penWidth = $width
        foreach ($toolbar in $script:toolbars) {
            $slider = $toolbar.FindName('PenSizeSlider')
            if ($slider.Value -ne $width) {
                $slider.Value = $width
            }
            $toolbar.FindName('PenSizeValue').Text = ('{0:0.#} px' -f $width)
            $toolbar.FindName('PenSizePreview').Height = $width
        }
    }

    function Set-EraserSize([double]$size) {
        $script:eraserSize = $size
        $script:eraserCursor.Width = $size
        $script:eraserCursor.Height = $size
        foreach ($toolbar in $script:toolbars) {
            $slider = $toolbar.FindName('EraserSizeSlider')
            if ($slider.Value -ne $size) {
                $slider.Value = $size
            }
            $toolbar.FindName('EraserSizeValue').Text = ('{0:0.#} px' -f $size)
            $preview = $toolbar.FindName('EraserSizePreview')
            $preview.Width = $size
            $preview.Height = $size
        }
    }

    function Set-PenColor([string]$color) {
        $script:penColor = $color
        $brush = [System.Windows.Media.BrushConverter]::new().ConvertFromString($color)
        foreach ($toolbar in $script:toolbars) {
            $toolbar.FindName('ColorSwatch').Fill = $brush
            $toolbar.FindName('PenSizePreview').Fill = $brush
            $toolbar.FindName('ColorPalettePopup').IsOpen = $false
        }
        if ($script:overlayHandle -ne [IntPtr]::Zero) {
            # Reapply input mode after the popup closes so the next stroke reaches the overlay.
            Set-Mode $script:mode
        }
    }

    function Bring-ToolbarsToFront {
        foreach ($toolbar in $script:toolbars) {
            $handle = [System.Windows.Interop.WindowInteropHelper]::new($toolbar).Handle
            if ($handle -ne [IntPtr]::Zero) {
                [PenAnnotator.WindowStyles]::BringToFront($handle)
            }
        }
    }

    function Update-SmoothStroke($stroke) {
        $points = $stroke.Points
        if ($points.Count -eq 0) {
            return
        }

        $figure = New-Object System.Windows.Media.PathFigure
        $figure.StartPoint = $points[0]
        if ($points.Count -eq 1) {
            $end = [System.Windows.Point]::new($points[0].X + 0.1, $points[0].Y)
            [void]$figure.Segments.Add(
                [System.Windows.Media.LineSegment]::new($end, $true))
        } elseif ($points.Count -eq 2) {
            [void]$figure.Segments.Add(
                [System.Windows.Media.LineSegment]::new($points[1], $true))
        } else {
            for ($index = 1; $index -lt ($points.Count - 1); $index++) {
                $control = $points[$index]
                $next = $points[$index + 1]
                $midpoint = [System.Windows.Point]::new(
                    ($control.X + $next.X) / 2,
                    ($control.Y + $next.Y) / 2)
                [void]$figure.Segments.Add(
                    [System.Windows.Media.QuadraticBezierSegment]::new(
                        $control, $midpoint, $true))
            }
            [void]$figure.Segments.Add(
                [System.Windows.Media.QuadraticBezierSegment]::new(
                    $points[$points.Count - 1],
                    $points[$points.Count - 1], $true))
        }

        $geometry = New-Object System.Windows.Media.PathGeometry
        [void]$geometry.Figures.Add($figure)
        $stroke.Shape.Data = $geometry
    }

    function Set-Mode([string]$newMode) {
        $script:mode = $newMode
        $active = [System.Windows.Media.BrushConverter]::new().ConvertFromString('#9958585E')
        $normal = [System.Windows.Media.BrushConverter]::new().ConvertFromString('Transparent')
        foreach ($toolbar in $script:toolbars) {
            $toolbar.FindName('PenSizePopup').IsOpen = $false
            $toolbar.FindName('EraserSizePopup').IsOpen = $false
            $toolbar.FindName('ColorPalettePopup').IsOpen = $false
            $penButton = [System.Windows.Controls.Button]$toolbar.FindName('PenButton')
            $selectButton = [System.Windows.Controls.Button]$toolbar.FindName('SelectButton')
            $eraserButton = [System.Windows.Controls.Button]$toolbar.FindName('EraserButton')
            $penButton.Background = $normal
            $selectButton.Background = $normal
            $eraserButton.Background = $normal

            if ($newMode -eq 'Pen') {
                $penButton.Background = $active
            } elseif ($newMode -eq 'Erase') {
                $eraserButton.Background = $active
            } else {
                $selectButton.Background = $active
            }
        }
        $script:eraserCursor.Visibility = if ($newMode -eq 'Erase') {
            [System.Windows.Visibility]::Visible
        } else {
            [System.Windows.Visibility]::Collapsed
        }
        $script:overlay.Cursor = if ($newMode -eq 'Pen') {
            [System.Windows.Input.Cursors]::Pen
        } elseif ($newMode -eq 'Erase') {
            [System.Windows.Input.Cursors]::Cross
        } else {
            [System.Windows.Input.Cursors]::Arrow
        }
        if ($newMode -eq 'Erase') {
            $script:eraserCursorTimer.Start()
        } else {
            $script:eraserCursorTimer.Stop()
        }

        if ($script:overlayHandle -ne [IntPtr]::Zero) {
            [PenAnnotator.WindowStyles]::SetOverlayMode(
                $script:overlayHandle, ($newMode -eq 'Select'))
            Bring-ToolbarsToFront
        }
    }

    function New-StrokeFromPoints($points, $brush, [double]$width) {
        $collection = New-Object System.Windows.Media.PointCollection
        foreach ($point in $points) {
            [void]$collection.Add($point)
        }
        $shape = New-Object System.Windows.Shapes.Path
        $shape.Stroke = $brush
        $shape.StrokeThickness = $width
        $shape.StrokeStartLineCap = [System.Windows.Media.PenLineCap]::Round
        $shape.StrokeEndLineCap = [System.Windows.Media.PenLineCap]::Round
        $shape.StrokeLineJoin = [System.Windows.Media.PenLineJoin]::Round
        $newStroke = [pscustomobject]@{ Shape = $shape; Points = $collection }
        Update-SmoothStroke $newStroke
        return $newStroke
    }

    function Remove-StrokesAt($point) {
        $updated = New-Object 'System.Collections.Generic.List[object]'
        $changed = $false
        foreach ($stroke in $script:strokes.ToArray()) {
            $radius = $script:eraserSize / 2 + $stroke.Shape.StrokeThickness / 2
            $strokeChanged = $false
            $fragments = [PenAnnotator.StrokeGeometry]::EraseStroke(
                $stroke.Points, $point, $point, $radius, [ref]$strokeChanged)
            if (-not $strokeChanged) {
                [void]$updated.Add($stroke)
                continue
            }

            $changed = $true
            foreach ($fragment in $fragments) {
                [void]$updated.Add((New-StrokeFromPoints `
                    $fragment $stroke.Shape.Stroke $stroke.Shape.StrokeThickness))
            }
        }

        if ($changed) {
            $script:eraseChanged = $true
            Restore-Strokes ($updated.ToArray())
        }
        return $changed
    }

    function Remove-StrokesAlong($start, $end) {
        $updated = New-Object 'System.Collections.Generic.List[object]'
        $changed = $false
        foreach ($stroke in $script:strokes.ToArray()) {
            $radius = $script:eraserSize / 2 + $stroke.Shape.StrokeThickness / 2
            $strokeChanged = $false
            $fragments = [PenAnnotator.StrokeGeometry]::EraseStroke(
                $stroke.Points, $start, $end, $radius, [ref]$strokeChanged)
            if (-not $strokeChanged) {
                [void]$updated.Add($stroke)
                continue
            }

            $changed = $true
            foreach ($fragment in $fragments) {
                [void]$updated.Add((New-StrokeFromPoints `
                    $fragment $stroke.Shape.Stroke $stroke.Shape.StrokeThickness))
            }
        }

        if ($changed) {
            $script:eraseChanged = $true
            Restore-Strokes ($updated.ToArray())
        }
    }

    $script:overlay.Add_SourceInitialized({
        $helper = [System.Windows.Interop.WindowInteropHelper]::new($script:overlay)
        $script:overlayHandle = $helper.Handle
        [PenAnnotator.WindowStyles]::SetOverlayMode($script:overlayHandle, $true)
    })

    $script:overlay.Add_PreviewMouseLeftButtonDown({
        foreach ($toolbar in $script:toolbars) {
            $toolbar.FindName('PenSizePopup').IsOpen = $false
            $toolbar.FindName('EraserSizePopup').IsOpen = $false
            $toolbar.FindName('ColorPalettePopup').IsOpen = $false
        }
        if ($script:mode -eq 'Pen') {
            $script:isDrawing = $true
            $point = $args[1].GetPosition($script:canvas)
            $points = New-Object System.Windows.Media.PointCollection
            [void]$points.Add($point)
            $smoothPath = New-Object System.Windows.Shapes.Path
            $smoothPath.Stroke = [System.Windows.Media.BrushConverter]::new().ConvertFromString(
                $script:penColor)
            $smoothPath.StrokeThickness = $script:penWidth
            $smoothPath.StrokeStartLineCap = [System.Windows.Media.PenLineCap]::Round
            $smoothPath.StrokeEndLineCap = [System.Windows.Media.PenLineCap]::Round
            $smoothPath.StrokeLineJoin = [System.Windows.Media.PenLineJoin]::Round
            $script:activeStroke = [pscustomobject]@{
                Shape = $smoothPath
                Points = $points
            }
            $script:strokeBefore = Get-StrokeSnapshot
            $script:strokes.Add($script:activeStroke)
            Update-SmoothStroke $script:activeStroke
            [void]$script:canvas.Children.Add($smoothPath)
            [void]$script:canvas.CaptureMouse()
            $args[1].Handled = $true
        } elseif ($script:mode -eq 'Erase') {
            $script:isErasing = $true
            $script:eraseChanged = $false
            $script:eraseBefore = Get-StrokeSnapshot
            $point = $args[1].GetPosition($script:canvas)
            $script:lastErasePoint = $point
            Update-EraserCursor $point
            [void](Remove-StrokesAt $point)
            [void]$script:canvas.CaptureMouse()
            $args[1].Handled = $true
        }
    })

    $script:overlay.Add_PreviewMouseMove({
        $point = $args[1].GetPosition($script:canvas)
        if ($script:isDrawing -and $script:activeStroke) {
            $last = $script:activeStroke.Points[$script:activeStroke.Points.Count - 1]
            $deltaX = $point.X - $last.X
            $deltaY = $point.Y - $last.Y
            if (($deltaX * $deltaX + $deltaY * $deltaY) -ge 0.5) {
                [void]$script:activeStroke.Points.Add($point)
                Update-SmoothStroke $script:activeStroke
            }
            $args[1].Handled = $true
        } elseif ($script:mode -eq 'Erase') {
            if ($script:isErasing) {
                Remove-StrokesAlong $script:lastErasePoint $point
                $script:lastErasePoint = $point
            }
            Update-EraserCursor $point
            $args[1].Handled = $true
        }
    })

    $script:overlay.Add_PreviewMouseLeftButtonUp({
        if ($script:isDrawing) {
            $point = $args[1].GetPosition($script:canvas)
            $last = $script:activeStroke.Points[$script:activeStroke.Points.Count - 1]
            $deltaX = $point.X - $last.X
            $deltaY = $point.Y - $last.Y
            if (($deltaX * $deltaX + $deltaY * $deltaY) -gt 0) {
                [void]$script:activeStroke.Points.Add($point)
                Update-SmoothStroke $script:activeStroke
            }
            Save-UndoSnapshot $script:strokeBefore
            $script:isDrawing = $false
            $script:activeStroke = $null
            $script:canvas.ReleaseMouseCapture()
            Bring-ToolbarsToFront
            $args[1].Handled = $true
        } elseif ($script:isErasing) {
            $point = $args[1].GetPosition($script:canvas)
            Remove-StrokesAlong $script:lastErasePoint $point
            Update-EraserCursor $point
            if ($script:eraseChanged) {
                Save-UndoSnapshot $script:eraseBefore
            }
            $script:isErasing = $false
            $script:lastErasePoint = $null
            $script:canvas.ReleaseMouseCapture()
            Bring-ToolbarsToFront
            $args[1].Handled = $true
        }
    })

    foreach ($toolbar in $script:toolbars) {
        $toolbar.FindName('DragGrip').Add_MouseLeftButtonDown({
            $grip = $args[0]
            $window = [System.Windows.Window]::GetWindow($grip)
            $args[1].Handled = $true
            $window.DragMove()
        })
        foreach ($sizeSlider in @(
            $toolbar.FindName('PenSizeSlider'),
            $toolbar.FindName('EraserSizeSlider')
        )) {
            $sizeSlider.Add_ValueChanged({
                if ($args[0].Name -eq 'PenSizeSlider') {
                    Set-PenWidth ([double]$args[0].Value)
                } else {
                    Set-EraserSize ([double]$args[0].Value)
                }
            })
            $sizeSlider.Add_PreviewMouseLeftButtonDown({
                $slider = $args[0]
                Update-SizeSliderFromPointer $slider ($args[1].GetPosition($slider))
                $script:activeSizeSlider = $slider
                [void]$slider.CaptureMouse()
                $args[1].Handled = $true
            })
            $sizeSlider.Add_PreviewMouseMove({
                $slider = $args[0]
                if ([object]::ReferenceEquals($script:activeSizeSlider, $slider) -and
                    $slider.IsMouseCaptured) {
                    Update-SizeSliderFromPointer $slider ($args[1].GetPosition($slider))
                    $args[1].Handled = $true
                }
            })
            $sizeSlider.Add_PreviewMouseLeftButtonUp({
                $slider = $args[0]
                if ([object]::ReferenceEquals($script:activeSizeSlider, $slider)) {
                    Update-SizeSliderFromPointer $slider ($args[1].GetPosition($slider))
                    $script:activeSizeSlider = $null
                    if ($slider.IsMouseCaptured) {
                        [void]$slider.ReleaseMouseCapture()
                    }
                    $args[1].Handled = $true
                }
            })
            $sizeSlider.Add_LostMouseCapture({
                if ([object]::ReferenceEquals($script:activeSizeSlider, $args[0])) {
                    $script:activeSizeSlider = $null
                }
            })
        }
        foreach ($swatch in $toolbar.FindName('PenColorPalette').Children) {
            if ($swatch.Name -ne 'CustomPenColorButton') {
                $swatch.Add_Click({
                    $color = [string]$args[0].Tag
                    Set-PenColor $color
                })
            }
        }
        $toolbar.FindName('CustomPenColorButton').Add_Click({
            $dialog = New-Object System.Windows.Forms.ColorDialog
            $dialog.AnyColor = $true
            $dialog.FullOpen = $true
            $dialog.Color = [System.Drawing.ColorTranslator]::FromHtml($script:penColor)
            if ($dialog.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
                $color = '#{0:X2}{1:X2}{2:X2}' -f
                    $dialog.Color.R, $dialog.Color.G, $dialog.Color.B
                Set-PenColor $color
            }
            $dialog.Dispose()
        })
        $toolbar.FindName('PenButton').Add_Click({
            $button = $args[0]
            Set-Mode 'Pen'
            $window = [System.Windows.Window]::GetWindow($button)
            $popup = $window.FindName('PenSizePopup')
            $popup.PlacementTarget = $button
            $popup.IsOpen = $true
        })
        $toolbar.FindName('SelectButton').Add_Click({ Set-Mode 'Select' })
        $toolbar.FindName('EraserButton').Add_Click({
            $button = $args[0]
            Set-Mode 'Erase'
            $window = [System.Windows.Window]::GetWindow($button)
            $popup = $window.FindName('EraserSizePopup')
            $popup.PlacementTarget = $button
            $popup.IsOpen = $true
        })
        $toolbar.FindName('ColorButton').Add_Click({
            $button = $args[0]
            $window = [System.Windows.Window]::GetWindow($button)
            $popup = $window.FindName('ColorPalettePopup')
            $wasOpen = $popup.IsOpen
            foreach ($targetToolbar in $script:toolbars) {
                $targetToolbar.FindName('PenSizePopup').IsOpen = $false
                $targetToolbar.FindName('EraserSizePopup').IsOpen = $false
                $targetToolbar.FindName('ColorPalettePopup').IsOpen = $false
            }
            if (-not $wasOpen) {
                $popup.StaysOpen = ($script:mode -ne 'Select')
                $popup.PlacementTarget = $button
                $popup.IsOpen = $true
            }
        })
        $toolbar.FindName('UndoButton').Add_Click({
            if ($script:undoStack.Count -gt 0) {
                [void]$script:redoStack.Add((Get-StrokeSnapshot))
                $last = $script:undoStack.Count - 1
                $snapshot = $script:undoStack[$last]
                $script:undoStack.RemoveAt($last)
                Restore-Strokes $snapshot
                Update-HistoryButtons
            }
        })
        $toolbar.FindName('RedoButton').Add_Click({
            if ($script:redoStack.Count -gt 0) {
                [void]$script:undoStack.Add((Get-StrokeSnapshot))
                $last = $script:redoStack.Count - 1
                $snapshot = $script:redoStack[$last]
                $script:redoStack.RemoveAt($last)
                Restore-Strokes $snapshot
                Update-HistoryButtons
            }
        })
        $toolbar.FindName('ClearButton').Add_Click({
            if ($script:strokes.Count -gt 0) {
                Save-UndoSnapshot (Get-StrokeSnapshot)
                $script:strokes.Clear()
                Restore-Strokes @()
            }
        })
        $toolbar.FindName('CloseButton').Add_Click({ $script:app.Shutdown() })
    }

    $script:app = New-Object System.Windows.Application
    $script:app.ShutdownMode = [System.Windows.ShutdownMode]::OnMainWindowClose
    $script:app.MainWindow = $script:toolbars[0]
    $script:overlay.Left = [System.Windows.SystemParameters]::VirtualScreenLeft
    $script:overlay.Top = [System.Windows.SystemParameters]::VirtualScreenTop
    $script:overlay.Width = [System.Windows.SystemParameters]::VirtualScreenWidth
    $script:overlay.Height = [System.Windows.SystemParameters]::VirtualScreenHeight
    Set-Mode 'Select'
    $script:overlay.Show()
    $screenTransform = [System.Windows.PresentationSource]::FromVisual(
        $script:overlay).CompositionTarget.TransformFromDevice
    for ($index = 0; $index -lt $script:toolbars.Count; $index++) {
        $toolbar = $script:toolbars[$index]
        $bounds = $script:screens[$index].Bounds
        $screenWidth = $bounds.Width * $screenTransform.M11
        $toolbar.Left = $bounds.Left * $screenTransform.M11 +
            ($screenWidth - $toolbar.Width) / 2
        $toolbar.Top = $bounds.Top * $screenTransform.M22 + 18
        $toolbar.Show()
    }
    [void]$script:app.Run()
} catch {
    $message = "The pen annotator could not start.`n`n$($_.Exception.Message)"
    try {
        [System.Windows.MessageBox]::Show($message, 'On-screen Pen',
            [System.Windows.MessageBoxButton]::OK, [System.Windows.MessageBoxImage]::Error) | Out-Null
    } catch {
        Write-Error $message
    }
    exit 1
}
